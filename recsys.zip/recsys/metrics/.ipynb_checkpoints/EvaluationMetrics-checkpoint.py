import numpy as np

def mae():
    return

def mse():
    return

def rmse():
    return